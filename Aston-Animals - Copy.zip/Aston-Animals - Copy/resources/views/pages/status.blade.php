@extends(Auth::user()->is_admin ? 'layouts.admin' : 'layouts.user')

<!-- this page is for users to see thier status of each adoption request, whether it is pending, accepted or declined -->

@section('content')


<h1>Check the status of your adoption requests here</h1>
@foreach ($animal_users as $animal_user)


<h2>Animal {{$animal_user->animal_name}}</h2>
@if ($animal_user->request == 'accepted' | $animal_user->request == 'declined')
<h3>Request status: {{$animal_user->request}}</h3>

@else

<h3>Request status: Pending</h3>

@endif

<hr>

@endforeach


@endsection
