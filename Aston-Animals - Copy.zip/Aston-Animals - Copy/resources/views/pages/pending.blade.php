@extends(Auth::user()->is_admin ? 'layouts.admin' : 'layouts.user')

@section('content')

<!-- this is the first page a admin would see when they logged in, it shows all pending adoption requests that a admin can accept or decline for any users
that made a animal request-->

<h1>Pending Adoption Requests</h1>

@foreach($animal_users as $animal_user)


<h2>user: {{$animal_user->user_name}} requested for: {{$animal_user->animal_name}}</h2>


<div class="d-flex">

{!! Form::open(['action' => ['App\Http\Controllers\AdoptionController@update', $animal_user->id], 'method' => 'POST']) !!}
{{Form::hidden('_method', 'PUT')}}
{{Form::submit('Accept', ['class' => 'btn btn-success', 'name' => 'accept'])}}
{!! Form::close() !!}


{!! Form::open(['action' => ['App\Http\Controllers\AdoptionController@update', $animal_user->id], 'method' => 'POST']) !!}
{{Form::hidden('_method', 'PUT')}}
{{Form::submit('Decline', ['class' => 'btn btn-danger', 'name' => 'decline'])}}
{!! Form::close() !!}

</div>

@if ($animal_user->request == 'accepted' | $animal_user->request == 'declined')


<h3>Request completed  status: {{$animal_user->request}}</h3>

@endif

<hr>


@endforeach

@endsection
