<!-- about page which users can if they are not logged in -->

@extends('layouts.app')

@section('content')
<h1>About</h1>
<p>this is the aboout page</p>
@endsection
