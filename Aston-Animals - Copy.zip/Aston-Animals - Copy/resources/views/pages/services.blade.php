@extends('layouts.app')

<!-- service page which can be seen when a user has not logged in yet -->

@section('content')
      <h1>{{$title}}</h1>

@if(count($services) > 0)
<ul class="list-group">
  @foreach($services as $service)
  <li class= "list-group-item">{{$service}}</li>
  @endforeach
</ul>

@endif

@endsection
