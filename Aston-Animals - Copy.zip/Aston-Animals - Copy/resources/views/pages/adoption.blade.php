@extends(Auth::user()->is_admin ? 'layouts.admin' : 'layouts.user')

<!-- page which shows all users thier adoption request seperatly from others, so each user can know which request they have made for an animal -->

@section('content')

<h1>Your Adoption Requests</h1>


@foreach ($animals as $animal)


<h2>Animal {{$animal->name}} requested</h2>
<img  style= "width:25%" src="/storage/cover_images/{{$animal->cover_image}}">
<h4>please be patient while the staff checks your request</h4>

<hr>

@endforeach

@endsection
