@extends(Auth::user()->is_admin ? 'layouts.admin' : 'layouts.user')

<!-- shows which user adopted which animal which only the admin can see -->

@section('content')

<h1>User Adopted list</h1>


@foreach($adopted as $adopted)

@if($adopted->request == 'accepted')

<h2>{{$adopted->user_name}} Adopted a {{$adopted->animal_name}} </h2>

@endif

<hr>

@endforeach



@endsection
