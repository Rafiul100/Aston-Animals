<!-- the first page a user sees -->
@extends('layouts.app')

@section('content')
<div class="jumbotron text-center">
  <h1>Weclome To Aston Animal Sanctuary</h1>


</div>


@endsection
