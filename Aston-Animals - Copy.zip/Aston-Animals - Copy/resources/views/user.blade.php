@extends('layouts.app')

@section('content')
<h1>Animals</h1>

@foreach($animals as $animal)
<div class="well">

  <h3><a href="/animals/{{$animal->id}}">{{$animal->name}}</a></h3>
  <small>Date of birth: {{$animal->date_of_birth}}</small>

</div>
@endforeach


<p>No Animals Found</p>


@endsection
