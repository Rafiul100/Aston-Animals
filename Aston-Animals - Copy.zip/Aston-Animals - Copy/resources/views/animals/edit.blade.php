@extends('layouts.app')


<!-- edit an existing animal information such as name, description or change the availability of the animals-->
@section('content')
<h1>Edit Animal Information</h1>
{!! Form::open(['action' => ['App\Http\Controllers\AnimalsController@update', $animal->id], 'method' => 'POST', 'enctype' => 'multipart/form-data']) !!}
    <div class="form-group">
      <?php//label has a name called 'title' which is used to reference the label, second parameter is what would be displayed to the user.?>
      {{Form::label('name', 'Name:')}}

      {{Form::text('name', $animal->name, ['class' => 'form-control', 'placeholder' => 'Name'])}}
<?php//label and textarea given names which they could be referenced from?>
      {{Form::label('description', 'Description:')}}
      {{Form::textarea('description', $animal->description, ['class' => 'form-control', 'placeholder' => 'Body text'])}}
<hr>
      {{Form::date('date', \Carbon\Carbon::now())}}
<div class="availability">
  <hr>
Availability:  Yes: {{Form::radio('availability', 'Yes')}}
   No: {{Form::radio('availability', 'No')}}
</div>
<div class="form-group">
  Add a picture: {{Form::file('cover_image')}}
  </div>


    </div>
    {{Form::hidden('_method', 'PUT')}}
    {{Form::submit('Submit', ['class' => 'btn btn-primary'])}}
{!! Form::close() !!}

@endsection
