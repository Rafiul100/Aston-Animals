@extends('layouts.admin')

<!-- add a new animal form -->
@section('content')
<h1>Add Animal</h1>
{!! Form::open(['action' => 'App\Http\Controllers\AnimalsController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']) !!}
    <div class="form-group">
      <?php//label has a name called 'title' which is used to reference the label, second parameter is what would be displayed to the user.?>
      {{Form::label('name', 'Name:')}}

      {{Form::text('name', '', ['class' => 'form-control', 'placeholder' => 'Name'])}}
<?php//label and textarea given names which they could be referenced from?>
      {{Form::label('description', 'Description:')}}
      {{Form::textarea('description', '', ['class' => 'form-control', 'placeholder' => 'Body text'])}}
<hr>
Date Of Birth: {{Form::date('date', \Carbon\Carbon::now())}}
<div class="availability">
  <hr>
   Availability:  Yes: {{Form::radio('availability', 'Yes')}}
   No: {{Form::radio('availability', 'No')}}
</div>
<div class="form-group">
  Add a picture: {{Form::file('cover_image')}}
  </div>



</div>
    {{Form::submit('Submit', ['class' => 'btn btn-primary'])}}
{!! Form::close() !!}

@endsection
