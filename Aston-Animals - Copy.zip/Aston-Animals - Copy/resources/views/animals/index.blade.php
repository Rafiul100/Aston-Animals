@extends(Auth::user()->is_admin ? 'layouts.admin' : 'layouts.user')


<!-- show the list of all animals to users so they can choose what animal to adopt, this is the first page a user sees once they logged in -->
@section('content')
<h1>Animals</h1>
@if(count($animals) > 0)
@foreach($animals as $animal)
<div class="well">
  <div class="row">
    <div class="col-md-4 col-sm-4">
<img  style= "width:100%" src="/storage/cover_images/{{$animal->cover_image}}">
    </div>
    <div class="col-md-8 col-sm-8">
      <h3><a href="/animals/{{$animal->id}}">Name: {{$animal->name}}</a></h3>
      <h4>Date of birth: {{$animal->date_of_birth}}</h4>

    </div>
</div>





  <hr>
</div>
@endforeach

@else
<p>No Animals Found</p>
@endif

@endsection
