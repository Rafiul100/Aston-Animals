@extends(Auth::user()->is_admin ? 'layouts.admin' : 'layouts.user')

@section('content')

<!-- when a user clicks the name of an animal it shows more information about this animal such as thier description and availability -->

<a href="/animals" class = 'btn btn-default'>Go Back</a>
<hr>
<h1>Name: {{$animal->name}}</h1>
<img  style= "width:25%" src="/storage/cover_images/{{$animal->cover_image}}">
<div>
  <br>
  Description: {{$animal->description}}
  <br>
  <br>
  Availability: {{$animal->availability}}
</div>
<hr>
<p>date of birth: {{$animal->date_of_birth}}</p>

@if($user->is_admin)

<a href="/animals/{{$animal->id}}/edit" class= "btn btn-default">Edit</a>

<?php//take you to destroy method once delete button clicked, giving its relevant id aswell?>
{!!Form::open(['action' => ['App\Http\Controllers\AnimalsController@destroy', $animal->id], 'method' => 'POST', 'class' => 'pull-right'])!!}
<?php//post does not work for delete so a hidden method is required to replace the method POST to DELETE method?>
{{Form::hidden('_method', 'DELETE')}}
<?php//attributes for a form field can be given in an array?>
{{Form::submit('Delete', ['class' => 'btn btn-danger'])}}
{!! Form::close() !!}


@else

@if ($animal->availability == 'Yes')

{!! Form::open(['action' => ['App\Http\Controllers\AdoptionController@update', $animal->id], 'method' => 'POST']) !!}
{{Form::hidden('_method', 'PUT')}}
{{Form::submit('Request Adoption', ['class' => 'btn btn-success'])}}
{!! Form::close() !!}

@else
<div>
  NOT AVAILABLE FOR ADOPTION
</div>


@endif

@endif


@endsection
