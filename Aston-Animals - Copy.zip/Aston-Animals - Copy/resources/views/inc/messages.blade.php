<!-- these are messages which will inform the admin with a successfull animal added/removed message, it also shows error messages
when the admin forgets to input a value into a required field-->

<?php //list through all the error messages that users make. errors that require users to make certain inputs for validation purposes?>
@if(count($errors)> 0)
@foreach($errors->all() as $error)
<div class="alert alert-danger">
  {{$error}}
</div>
@endforeach
@endif


<?php //message to show success of all validation being successfull ?>
@if(session('success'))
<div class="alert alert-success">
  {{session('success')}}
</div>
@endif


<?php //show a single error if input doesnt meet validation ?>
@if(session('error'))
<div class="alert alert-danger">
  {{session('error')}}
</div>
@endif
