<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddPendingRequestToPivot extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
     //additional request column was added so that users request of pending, accepted or declined can also be saved
    public function up()
    {
        Schema::table('animal_user', function (Blueprint $table) {
            $table->string('request')->default('');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('animal_user', function (Blueprint $table) {
              $table->dropColumn('request');
        });
    }
}
