<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddTimestampToAnimal extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */

     //timestamp was also added to animals table as its required to show the list of animals to users in ascending or descending order
     //depending on what date and time the animal was added by the admin.
     //or the list of animals can be shown in a alphbetical order instead of showing the time it was added to the list.   
    public function up()
    {
        Schema::table('animals', function (Blueprint $table) {
            $table->timestamp('created_at');

        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('animals', function (Blueprint $table) {
            $table->dropColumn('created_at');
        });
    }
}
