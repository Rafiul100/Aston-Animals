<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class AddAnimalPictureToPost extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */

     //additional cover_image column was added to animals table so that it can store images information
     //so that it can be shown to users and admin whenever required  
    public function up()
    {
        Schema::table('animals', function (Blueprint $table) {
            $table->string('cover_image');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::table('animals', function (Blueprint $table) {
            $table->dropColumn ('cover_image');
        });
    }
}
