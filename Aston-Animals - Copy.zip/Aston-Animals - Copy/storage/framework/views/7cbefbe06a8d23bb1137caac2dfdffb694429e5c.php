

<!-- page which shows all users thier adoption request seperatly from others, so each user can know which request they have made for an animal -->

<?php $__env->startSection('content'); ?>

<h1>Your Adoption Requests</h1>

<?php if(count($animals) > 0): ?>
<?php $__currentLoopData = $animals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<h2>Animal <?php echo e($animal->name); ?> requested</h2>
<img  style= "width:25%" src="/storage/cover_images/<?php echo e($animal->cover_image); ?>">
<h4>please be patient while the staff checks your request</h4>

<hr>

<?php else: ?>

<h2>You have made no adoption request</h2>


<?php endif; ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make(Auth::user()->is_admin ? 'layouts.admin' : 'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rabiu\Aston-Animals\resources\views/pages/adoption.blade.php ENDPATH**/ ?>