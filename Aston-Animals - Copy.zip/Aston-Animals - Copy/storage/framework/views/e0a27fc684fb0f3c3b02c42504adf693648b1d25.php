

<?php $__env->startSection('content'); ?>

<!-- this is the first page a admin would see when they logged in, it shows all pending adoption requests that a admin can accept or decline for any users
that made a animal request-->

<h1>Pending Adoption Requests</h1>

<?php $__currentLoopData = $animal_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<h2>user: <?php echo e($animal_user->user_name); ?> requested for: <?php echo e($animal_user->animal_name); ?></h2>


<div class="d-flex">

<?php echo Form::open(['action' => ['App\Http\Controllers\AdoptionController@update', $animal_user->id], 'method' => 'POST']); ?>

<?php echo e(Form::hidden('_method', 'PUT')); ?>

<?php echo e(Form::submit('Accept', ['class' => 'btn btn-success', 'name' => 'accept'])); ?>

<?php echo Form::close(); ?>



<?php echo Form::open(['action' => ['App\Http\Controllers\AdoptionController@update', $animal_user->id], 'method' => 'POST']); ?>

<?php echo e(Form::hidden('_method', 'PUT')); ?>

<?php echo e(Form::submit('Decline', ['class' => 'btn btn-danger', 'name' => 'decline'])); ?>

<?php echo Form::close(); ?>


</div>

<?php if($animal_user->request == 'accepted' | $animal_user->request == 'declined'): ?>


<h3>Request completed  status: <?php echo e($animal_user->request); ?></h3>

<?php endif; ?>

<hr>


<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make(Auth::user()->is_admin ? 'layouts.admin' : 'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rabiu\Aston-Animals\resources\views/pages/pending.blade.php ENDPATH**/ ?>