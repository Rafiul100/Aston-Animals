

<!-- shows which user adopted which animal which only the admin can see -->

<?php $__env->startSection('content'); ?>

<h1>User Adopted list</h1>


<?php $__currentLoopData = $adopted; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $adopted): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<?php if($adopted->request == 'accepted'): ?>

<h2><?php echo e($adopted->user_name); ?> Adopted a <?php echo e($adopted->animal_name); ?> </h2>

<?php endif; ?>

<hr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



<?php $__env->stopSection(); ?>

<?php echo $__env->make(Auth::user()->is_admin ? 'layouts.admin' : 'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rabiu\Aston-Animals\resources\views/pages/adopted.blade.php ENDPATH**/ ?>