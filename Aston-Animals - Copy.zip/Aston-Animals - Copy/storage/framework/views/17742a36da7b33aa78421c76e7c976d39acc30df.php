

<!-- add a new animal form -->
<?php $__env->startSection('content'); ?>
<h1>Add Animal</h1>
<?php echo Form::open(['action' => 'App\Http\Controllers\AnimalsController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

    <div class="form-group">
      <?php//label has a name called 'title' which is used to reference the label, second parameter is what would be displayed to the user.?>
      <?php echo e(Form::label('name', 'Name:')); ?>


      <?php echo e(Form::text('name', '', ['class' => 'form-control', 'placeholder' => 'Name'])); ?>

<?php//label and textarea given names which they could be referenced from?>
      <?php echo e(Form::label('description', 'Description:')); ?>

      <?php echo e(Form::textarea('description', '', ['class' => 'form-control', 'placeholder' => 'Body text'])); ?>

<hr>
Date Of Birth: <?php echo e(Form::date('date', \Carbon\Carbon::now())); ?>

<div class="availability">
  <hr>
   Availability:  Yes: <?php echo e(Form::radio('availability', 'Yes')); ?>

   No: <?php echo e(Form::radio('availability', 'No')); ?>

</div>
<div class="form-group">
  Add a picture: <?php echo e(Form::file('cover_image')); ?>

  </div>



</div>
    <?php echo e(Form::submit('Submit', ['class' => 'btn btn-primary'])); ?>

<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rabiu\Aston-Animals\resources\views/animals/create.blade.php ENDPATH**/ ?>