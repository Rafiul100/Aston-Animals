<!-- these are messages which will inform the admin with a successfull animal added/removed message, it also shows error messages
when the admin forgets to input a value into a required field-->

<?php //list through all the error messages that users make. errors that require users to make certain inputs for validation purposes?>
<?php if(count($errors)> 0): ?>
<?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="alert alert-danger">
  <?php echo e($error); ?>

</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>


<?php //message to show success of all validation being successfull ?>
<?php if(session('success')): ?>
<div class="alert alert-success">
  <?php echo e(session('success')); ?>

</div>
<?php endif; ?>


<?php //show a single error if input doesnt meet validation ?>
<?php if(session('error')): ?>
<div class="alert alert-danger">
  <?php echo e(session('error')); ?>

</div>
<?php endif; ?>
<?php /**PATH C:\Users\rabiu\Aston-Animals\resources\views/inc/messages.blade.php ENDPATH**/ ?>