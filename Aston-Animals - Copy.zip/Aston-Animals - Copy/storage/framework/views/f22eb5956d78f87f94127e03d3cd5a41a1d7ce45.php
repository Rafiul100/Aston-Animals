<!-- the first page a user sees -->


<?php $__env->startSection('content'); ?>
<div class="jumbotron text-center">
  <h1>Weclome To Aston Animal Sanctuary</h1>


</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rabiu\Aston-Animals\resources\views/pages/index.blade.php ENDPATH**/ ?>