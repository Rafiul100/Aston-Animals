


<!-- show the list of all animals to users so they can choose what animal to adopt, this is the first page a user sees once they logged in -->
<?php $__env->startSection('content'); ?>
<h1>Animals</h1>
<?php if(count($animals) > 0): ?>
<?php $__currentLoopData = $animals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="well">
  <div class="row">
    <div class="col-md-4 col-sm-4">
<img  style= "width:100%" src="/storage/cover_images/<?php echo e($animal->cover_image); ?>">
    </div>
    <div class="col-md-8 col-sm-8">
      <h3><a href="/animals/<?php echo e($animal->id); ?>">Name: <?php echo e($animal->name); ?></a></h3>
      <h4>Date of birth: <?php echo e($animal->date_of_birth); ?></h4>

    </div>
</div>





  <hr>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php else: ?>
<p>No Animals Found</p>
<?php endif; ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make(Auth::user()->is_admin ? 'layouts.admin' : 'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rabiu\Aston-Animals\resources\views/animals/index.blade.php ENDPATH**/ ?>