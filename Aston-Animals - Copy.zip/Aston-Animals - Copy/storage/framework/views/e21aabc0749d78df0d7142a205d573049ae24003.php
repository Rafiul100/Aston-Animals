

<!-- this page is for users to see thier status of each adoption request, whether it is pending, accepted or declined -->

<?php $__env->startSection('content'); ?>


<h1>Check the status of your adoption requests here</h1>
<?php $__currentLoopData = $animal_users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $animal_user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


<h2>Animal <?php echo e($animal_user->animal_name); ?></h2>
<?php if($animal_user->request == 'accepted' | $animal_user->request == 'declined'): ?>
<h3>Request status: <?php echo e($animal_user->request); ?></h3>

<?php else: ?>

<h3>Request status: Pending</h3>

<?php endif; ?>

<hr>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make(Auth::user()->is_admin ? 'layouts.admin' : 'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rabiu\Aston-Animals\resources\views/pages/status.blade.php ENDPATH**/ ?>