

<?php $__env->startSection('content'); ?>

<!-- when a user clicks the name of an animal it shows more information about this animal such as thier description and availability -->

<a href="/animals" class = 'btn btn-default'>Go Back</a>
<hr>
<h1>Name: <?php echo e($animal->name); ?></h1>
<img  style= "width:25%" src="/storage/cover_images/<?php echo e($animal->cover_image); ?>">
<div>
  <br>
  Description: <?php echo e($animal->description); ?>

  <br>
  <br>
  Availability: <?php echo e($animal->availability); ?>

</div>
<hr>
<p>date of birth: <?php echo e($animal->date_of_birth); ?></p>

<?php if($user->is_admin): ?>

<a href="/animals/<?php echo e($animal->id); ?>/edit" class= "btn btn-default">Edit</a>

<?php//take you to destroy method once delete button clicked, giving its relevant id aswell?>
<?php echo Form::open(['action' => ['App\Http\Controllers\AnimalsController@destroy', $animal->id], 'method' => 'POST', 'class' => 'pull-right']); ?>

<?php//post does not work for delete so a hidden method is required to replace the method POST to DELETE method?>
<?php echo e(Form::hidden('_method', 'DELETE')); ?>

<?php//attributes for a form field can be given in an array?>
<?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

<?php echo Form::close(); ?>



<?php else: ?>

<?php if($animal->availability == 'Yes'): ?>

<?php echo Form::open(['action' => ['App\Http\Controllers\AdoptionController@update', $animal->id], 'method' => 'POST']); ?>

<?php echo e(Form::hidden('_method', 'PUT')); ?>

<?php echo e(Form::submit('Request Adoption', ['class' => 'btn btn-success'])); ?>

<?php echo Form::close(); ?>


<?php else: ?>
<div>
  NOT AVAILABLE FOR ADOPTION
</div>


<?php endif; ?>

<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make(Auth::user()->is_admin ? 'layouts.admin' : 'layouts.user', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rabiu\Aston-Animals\resources\views/animals/show.blade.php ENDPATH**/ ?>