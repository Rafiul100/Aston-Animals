<!-- about page which users can if they are not logged in -->



<?php $__env->startSection('content'); ?>
<h1>About</h1>
<p>this is the aboout page</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\rabiu\Aston-Animals\resources\views/pages/about.blade.php ENDPATH**/ ?>