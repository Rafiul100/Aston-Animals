<?php

namespace App\Http\Controllers;



use App\Models\Animal;
use Illuminate\Http\Request;
use App\Models\Animal_user;
use App\Models\User;

//links for all pages when users dont login including other pages such as adopted, pending, and status pages
//which are shown to users or admins whenever they are logged in.

class PagesController extends Controller
{
public function index() {
  $title = 'welcome to laravel!';
return view('pages.index')->with('title', $title);


}

public function about() {
return view('pages.about');

}

public function services() {
  //sending multiple variables to view file.
$data = array(
  'title' => 'Services',
  'services' => ['Adopt a pet', 'choose from a variety of pet', 'veterinary services']
);
return view('pages.services')->with($data);
}


public function adopted() {
$adopted = Animal_user::all();
return view('pages.adopted')->with('adopted', $adopted);
}


public function pending() {
return view('pages.pending');
}


public function status() {
$user = User::find(auth()->user()->id);
$animal_users = Animal_user::where('user_id', $user->id)->get();
return view('pages.status')->with('animal_users', $animal_users);
}

}
