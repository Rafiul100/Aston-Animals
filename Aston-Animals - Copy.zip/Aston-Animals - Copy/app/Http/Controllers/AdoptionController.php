<?php

namespace App\Http\Controllers;

use App\Models\User;
use App\Models\Animal;
use App\Models\Animal_user;
use Auth;
use Illuminate\Http\Request;
use App\Models\Adoption;





class AdoptionController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */


     //AdoptionController has some crud functionalities such as showing the list of adoption request made by users individually
     //and showing the list of pending requests that only a admin can see and decide if they will accept or decline them (index method).
    public function index()
    {

$user = User::find(auth()->user()->id);

if($user->is_admin) {
$animal_users = Animal_user::all();


return view('pages.pending')->with('animal_users', $animal_users);

}
else {

$animal_users = Animal_user::where('user_id', $user->id)->get();

foreach($animal_users as $animal_user) {

$allAnimal_id[] = $animal_user->animal_id;

}

$animals = Animal::find($allAnimal_id);

return view('pages.adoption')->with('animals', $animals);

}

}

     //with the adoption model/table, i would need to get the id of the user thats signed in into the adoption user_id column
     //and the id of the animal that has been requested to be adopted into the animal_id coulumn of the adoption table/model.


     //create the view for admin so that admin can see all the pending adoption request by creating if statement to check if current user is a admin or not.

     //try to get the code not to create a new row for the staff user
     //but instead to edit the existing user, referencing it from its id to add the new column 'requests' with an input of accepted or declined.



     //the update method is used to update the animal_user request column with 'accepted' or 'decline' value.
     //the update method is also used to create a row in animal_user table whenever a user clicks the 'request adoption' button
     //it will store which user made the request for a particular animal so that it can be used in any view to show users thier individual animals adoption requests
     //as well as other requirements
    public function update(Request $request, $id) {

if(auth()->user()->is_admin )  {

$animal_user1 = Animal_user::find($id);

if($request->input('accept'))
{
 $animal_user1->request = 'accepted';

}
else if($request->input('decline'))
{
  $animal_user1->request = 'declined';
}

}

else {

$animal_user1 = new Animal_user;

$user = User::find(auth()->user()->id);
$animal = Animal::find($id);

  $animal_user1->animal_name = $animal->name;
  $animal_user1->user_id = $user->id;
  $animal_user1->animal_id = $animal->id;
  $animal_user1->user_name = $user->name;

}

$animal_user1->save();
$user = User::find(auth()->user()->id);

    $animal_users = Animal_user::where('user_id', $user->id)->get();

    foreach($animal_users as $animal_user) {

    $allAnimal_id[] = $animal_user->animal_id;

    $animals = Animal::find($allAnimal_id);

    $data = array (
      'animals' => $animals,
      'animal_user' => $animal_user1,
    );
}

if(auth()->user()->is_admin )  {
return redirect('/pending');
}
return view('pages.adoption')->with($data);
}



}
