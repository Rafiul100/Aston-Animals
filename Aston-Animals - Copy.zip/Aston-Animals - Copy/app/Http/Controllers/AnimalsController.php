<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use App\Models\Animal;
use App\Models\User;


class AnimalsController extends Controller
{
  /**
   * Create a new controller instance.
   *
   * @return void
   */
  public function __construct()
  {
      $this->middleware('auth');
  }

//AnimalsController has all crud method functionality such as create, read, update and delete. these methods are needed so that a animal can be added
//to a list, shown individually, allows for update of animals information that only a admin can do, and allow deletion of animal that only a admin can do.

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
      //the list of animals that users and admin can view are ordered alphabetically.
    $animals = Animal::orderBy('name', 'desc')->get();
    return view('animals.index')->with('animals', $animals);
}

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view ('animals.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
      //validate information which the admin stores about a animal. makes sure that each field is required
      //when a admin is about to add a new animals. cover_image is required to be a image only and can be nullable (optional).
        $this->validate($request, [
          'name' => 'required',
          'description' => 'required',
          'date' => 'required',
          'availability' => 'required',
          'cover_image' => 'image|nullable|max:1999'

        ]);

   //Handle file upload
  if($request->hasFile('cover_image')){
//get filename with the extention
$filenameWithExt = $request->file('cover_image')->getClientOriginalName();
//get just filename
$filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
//get just ext
$extension = $request->file('cover_image')->getClientOriginalExtension();
//filename to store
$fileNameToStore = $filename.'_'.time().'.'.$extension;
//upload image
$path = $request->file('cover_image')->storeAs('public/cover_images', $fileNameToStore);
}else{
$fileNameToStore = 'noimage.jpg';
  }


        //add animal
        $animal = new Animal;
        $animal->name = $request->input('name');
        $animal->description = $request->input('description');
        $animal->date_of_birth = $request->input('date');
        $animal->availability = $request->input('availability');
        $animal->cover_image = $fileNameToStore;

        $animal->save();

        return redirect('/animals')->with('success', 'Animal added');
}

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $animal = Animal::find($id);
        $user = User::find(auth()->user()->id);

 $data = array(
   'animal' => $animal,
   'user' => $user
 );

  return view('animals.show')->with($data);
   }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
      $animal = Animal::find($id);
      return view('animals.edit')->with('animal', $animal);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
      $this->validate($request, [
        'name' => 'required',
        'description' => 'required',
        'date' => 'required',
        'availability' => 'required'

      ]);

      //Handle file upload
     if($request->hasFile('cover_image')){
   //get filename with the extention
   $filenameWithExt = $request->file('cover_image')->getClientOriginalName();
   //get just filename
   $filename = pathinfo($filenameWithExt, PATHINFO_FILENAME);
   //get just ext
   $extension = $request->file('cover_image')->getClientOriginalExtension();
   //filename to store
   $fileNameToStore = $filename.'_'.time().'.'.$extension;
   //upload image
   $path = $request->file('cover_image')->storeAs('public/cover_images', $fileNameToStore);
   }

      //update an animal
      $animal = Animal::find($id);
      $animal->name = $request->input('name');
      $animal->description = $request->input('description');
      $animal->date_of_birth = $request->input('date');
      $animal->availability = $request->input('availability');
      if($request->hasFile('cover_image')){
      $animal->cover_image = $fileNameToStore;
    }

    $animal->save();

    return redirect('/animals')->with('success', 'Animal Updated');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $animal = Animal::find($id);
        $animal->delete();

        if($animal->cover_image != 'noimage.jpg') {
          //delete image
          Storage::delete('public/cover_images/'.$animal->cover_image);
        }

        return redirect('/animals')->with('success', 'Animal Removed');
    }
}
