<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
//model which is used to show data from the Animal_user table, such as request, animal_name and user_name data which is used in the AdoptionController. 
class Animal_user extends Model
{
    use HasFactory;
    protected $table = 'animal_user';
    public $primaryKey = 'id';
}
