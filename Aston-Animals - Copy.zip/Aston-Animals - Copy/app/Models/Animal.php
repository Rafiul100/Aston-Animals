<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
//model which is used to show animals data, such as thier name, date of birth and description. the data is called and manipulated in the AnimalsController.  
class Animal extends Model
{
    use HasFactory;
    //name of table
    protected $table = 'animals';

    public $primaryKey = 'id';

    public $timestamps = false;



//relationship with animal, where a user can adopt multiple animals.
    public function users(){

return $this->belongsToMany(User::class);
    }

}
