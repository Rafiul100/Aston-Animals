<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/


//resource routes- AnimalsController and AdoptionController have CRUD functionality which requires each endpoint to be linked to
//each CRUD method. resource allows for an easier way to create these routes with just one route.
Route::resource('animals', 'App\Http\Controllers\AnimalsController');
Route::resource('adoptions', 'App\Http\Controllers\AdoptionController');

//pages routes- these are the pages for users to see when they are not logged in (about and services page),
//adopted page on a admin account to see what users adopted what animal
//status page on user account to see if thier request was accepted or declined
Route::get('/', 'App\Http\Controllers\PagesController@index');
Route::get('/about', 'App\Http\Controllers\PagesController@about');
Route::get('/services', 'App\Http\Controllers\PagesController@services');
Route::get('/adopted', 'App\Http\Controllers\PagesController@adopted');
Route::get('/status', 'App\Http\Controllers\PagesController@status');

//Animals routes- although AnimalsController have thier routes already thier are some additional end points which require to use the AnimalsController
Route::get('/animals/create', 'App\Http\Controllers\AnimalsController@create');
Route::get('user',  'App\Http\Controllers\AnimalsController@index', ['middleware' => 'auth', function() {
}]);

//adoption routes- used to get information about what user adopted what animal.
Route::get('admin','App\Http\Controllers\AdoptionController@index', ['middleware' => 'isadmin', function() {
}]);
Route::get('/pending', 'App\Http\Controllers\AdoptionController@index');
Route::get('/adoptions' , 'App\Http\Controllers\AdoptionController@index');

//athentication routes
Auth::routes();
